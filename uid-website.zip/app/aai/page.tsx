import { ArrowRight, ChevronRight } from "lucide-react"
import TopNav from "@/components/aai/top-nav"
import HeroSearch from "@/components/aai/hero-search"
import NoticeTabs from "@/components/aai/notice-tabs"

export default function Page() {
  return (
    <main className="min-h-screen bg-[#ffffff] text-[#0d141c]">
      <TopNav />
      <HeroSearch />
      <section className="mx-auto max-w-5xl px-6 py-10">
        {/* banner placeholder */}
        <div className="rounded-lg border border-[#e5e8eb] bg-[#e5e8eb] h-40 w-full" aria-hidden="true" />
      </section>

      <section className="mx-auto max-w-5xl px-6 pb-12">
        <NoticeTabs />
      </section>

      <section className="mx-auto max-w-5xl px-6 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Important Links</h3>
            <ul className="list-none space-y-4">
              <li>
                <a className="text-[#0766e5] underline-offset-2 hover:underline" href="#">
                  Media/Press Releases
                </a>
              </li>
              <li>
                <a className="text-[#0766e5] underline-offset-2 hover:underline" href="#">
                  Training Institutes
                </a>
              </li>
            </ul>

            <div className="pt-6">
              <h3 className="text-lg font-semibold">Contact Us</h3>
              <div className="mt-4 text-sm leading-6">
                <p>Indian Airport Authority Headquarters</p>
                <p>Rajiv Gandhi Bhawan, Safdarjung Airport,</p>
                <p>New Delhi: 110003</p>
                <p>Phone: +91-11-12345678</p>
                <p>Fax: +91-11-98765432</p>
                <p>Email: contact@indianairportauthority.gov.in</p>
              </div>
            </div>
          </div>

          <div className="flex items-start justify-end gap-6">
            <button
              aria-label="Go to next section"
              className="rounded-full border border-[#e5e8eb] p-3 hover:bg-[#e6edff] transition-colors"
            >
              <ChevronRight className="h-5 w-5 text-[#0d141c]" />
            </button>
            <button
              aria-label="Go to next section"
              className="rounded-full border border-[#e5e8eb] p-3 hover:bg-[#e6edff] transition-colors"
            >
              <ArrowRight className="h-5 w-5 text-[#0d141c]" />
            </button>
          </div>
        </div>
      </section>
    </main>
  )
}
