"use client"

import { usePathname } from "next/navigation"

export default function TopNav() {
  const pathname = usePathname()
  const items = [
    { label: "Airports", href: "/aai/airports" },
    { label: "Business Info", href: "#" },
    { label: "Services", href: "#" },
    { label: "Tenders", href: "/aai/tenders" },
    { label: "Vigilance", href: "#" },
    { label: "Public Info", href: "/aai/public-info" },
  ]
  return (
    <header className="w-full border-b border-[#e5e8eb] bg-[#ffffff]">
      <div className="mx-auto max-w-6xl px-6">
        <nav className="flex h-11 items-center justify-between text-xs">
          <ul className="flex items-center gap-5">
            {items.map((item) => {
              const active = pathname?.startsWith(item.href) && item.href !== "#"
              return (
                <li key={item.label}>
                  <a
                    href={item.href}
                    className={`relative inline-flex items-center pb-2 text-[#0d141c] hover:text-[#0766e5] ${
                      active ? "text-[#0766e5]" : ""
                    }`}
                    aria-current={active ? "page" : undefined}
                  >
                    {item.label}
                    {active && (
                      <span
                        aria-hidden="true"
                        className="absolute -bottom-[2px] left-0 h-[2px] w-full bg-[#0766e5] rounded"
                      />
                    )}
                  </a>
                </li>
              )
            })}
          </ul>
          <div className="flex items-center gap-4">
            <button aria-label="Language" className="h-6 w-6 rounded-full border border-[#e5e8eb] bg-[#ffffff]" />
            <button aria-label="Profile" className="h-6 w-6 rounded-full border border-[#e5e8eb] bg-[#ffffff]" />
          </div>
        </nav>
      </div>
    </header>
  )
}
