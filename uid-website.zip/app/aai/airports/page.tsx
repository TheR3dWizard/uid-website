import type React from "react"
import TopNav from "@/components/aai/top-nav"
import { Landmark, HelpCircle, MapPin, ImageIcon, Building2, ShoppingCart, Award, GaugeCircle } from "lucide-react"

const cityPills = [
  "Mumbai",
  "Delhi",
  "Kolkata",
  "Hyderabad",
  "Bengaluru",
  "Chennai",
  "Kochi",
  "Patna",
  "Coimbatore",
  "Goa",
]

function IconTile({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-20 w-20 items-center justify-center rounded-md bg-[#3c4ba7] text-[#ffffff] shadow-sm">
      {children}
    </div>
  )
}

export default function Page() {
  return (
    <main className="min-h-screen bg-[#ffffff] text-[#0d141c]">
      <TopNav />

      {/* Hero search */}
      <section className="w-full bg-[#e6edff]">
        <div className="mx-auto max-w-6xl px-6 py-6">
          <form
            className="mx-auto flex max-w-xl items-stretch overflow-hidden rounded-md border border-[#e5e8eb] bg-[#ffffff]"
            role="search"
            aria-label="Airport search"
          >
            <input
              placeholder="Find Airports by Name or City"
              className="w-full px-4 py-3 text-sm outline-none placeholder:text-[#0d141c]/60"
            />
            <button
              type="submit"
              className="bg-[#0766e5] px-5 py-3 text-sm font-medium text-[#ffffff] hover:opacity-95"
            >
              Find Airports
            </button>
          </form>

          <div className="mt-4 flex flex-wrap justify-center gap-3">
            {cityPills.map((p) => (
              <a
                key={p}
                href="#"
                className="rounded-full border border-[#e5e8eb] bg-[#ffffff] px-3 py-1 text-xs hover:bg-[#e6edff]"
              >
                {p}
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Featured image */}
      <section className="mx-auto max-w-6xl px-6 py-8">
        <ImageIcon
          alt="Airport exterior"
          src="/airport-gallery-image.jpg"
          className="w-full rounded-lg border border-[#e5e8eb] object-cover"
        />
      </section>

      {/* Icon grid */}
      <section className="mx-auto max-w-6xl px-6">
        <div className="grid grid-cols-3 place-items-center gap-6 md:grid-cols-6">
          <IconTile>
            <Building2 className="h-8 w-8" />
          </IconTile>
          <IconTile>
            <HelpCircle className="h-8 w-8" />
          </IconTile>
          <IconTile>
            <MapPin className="h-8 w-8" />
          </IconTile>
          <IconTile>
            <ImageIcon className="h-8 w-8" />
          </IconTile>
          <IconTile>
            <Landmark className="h-8 w-8" />
          </IconTile>
          <IconTile>
            <ShoppingCart className="h-8 w-8" />
          </IconTile>
          <IconTile>
            <Award className="h-8 w-8" />
          </IconTile>
          <IconTile>
            <GaugeCircle className="h-8 w-8" />
          </IconTile>
        </div>
      </section>

      {/* Footer info */}
      <section className="mx-auto max-w-6xl px-6 pb-16 pt-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2">
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Important Links</h3>
            <ul className="space-y-4">
              <li>
                <a className="text-[#0766e5] hover:underline underline-offset-2" href="#">
                  Media/Press Releases
                </a>
              </li>
              <li>
                <a className="text-[#0766e5] hover:underline underline-offset-2" href="#">
                  Training Institutes
                </a>
              </li>
            </ul>
            <div>
              <h3 className="text-lg font-semibold">Contact Us</h3>
              <div className="mt-4 text-sm leading-6">
                <p>Indian Airport Authority Headquarters</p>
                <p>Rajiv Gandhi Bhawan, Safdarjung Airport,</p>
                <p>New Delhi: 110003</p>
                <p>Phone: +91-11-12345678</p>
                <p>Fax: +91-11-98765432</p>
                <p>Email: contact@indianairportauthority.gov.in</p>
              </div>
            </div>
          </div>
          <div className="flex items-start justify-end gap-6">
            <button aria-label="Next" className="rounded-full border border-[#e5e8eb] p-3 hover:bg-[#e6edff]" />
            <button aria-label="Next" className="rounded-full border border-[#e5e8eb] p-3 hover:bg-[#e6edff]" />
          </div>
        </div>
      </section>
    </main>
  )
}
