import TopNav from "@/components/aai/top-nav"
import { Download, Eye, Bookmark } from "lucide-react"

const sidebar = [
  "Tender Search",
  "E-Tender",
  "Notice inviting Tender",
  "Restriction on Issue of Tender for AAI Projects",
  "Contract Award",
  "Status of Tenders/Contracts",
]

const rows = [
  {
    id: 1,
    title: "Tender in Progress for Infrastructure Development and Modernization Project in August 2025",
    date: "23-08-2025",
  },
  {
    id: 2,
    title: "Tender Published for Airport Terminal Expansion and Construction Services in August 2025",
    date: "22-08-2025",
  },
  {
    id: 3,
    title: "No Response Tender for Maintenance and Repair Services Contract in August 2025",
    date: "22-08-2025",
  },
  {
    id: 4,
    title: "Tender Published for Supply of Equipment and Materials for Aviation Operations in July 2025",
    date: "13-08-2025",
  },
  {
    id: 5,
    title: "Tender in Progress for Technical Consultancy and Advisory Services Project in July 2025",
    date: "13-08-2025",
  },
]

export default function Page() {
  return (
    <main className="min-h-screen bg-[#ffffff] text-[#0d141c]">
      <TopNav />
      <section className="mx-auto max-w-6xl px-6 py-6 md:py-8">
        <div className="flex gap-6">
          {/* Sidebar */}
          <aside className="hidden w-64 shrink-0 rounded-md border border-[#e5e8eb] md:block">
            <div className="bg-[#e6edff] px-4 py-3 text-xs font-semibold text-[#0d141c]">TENDER</div>
            <nav className="p-2">
              <ul className="text-sm">
                {sidebar.map((label, i) => {
                  const active = label === "Status of Tenders/Contracts"
                  return (
                    <li key={label}>
                      <a
                        href="#"
                        className={`block rounded px-3 py-2 ${
                          active ? "bg-[#3c4ba7] text-[#ffffff]" : "text-[#0d141c] hover:bg-[#e6edff]"
                        }`}
                        aria-current={active ? "page" : undefined}
                      >
                        {label}
                      </a>
                    </li>
                  )
                })}
              </ul>
            </nav>
          </aside>

          {/* Main */}
          <div className="flex-1">
            <div className="rounded-md border border-[#e5e8eb] bg-[#ffffff]">
              <header className="flex items-center justify-between border-b border-[#e5e8eb] px-4 py-3">
                <h2 className="text-base font-semibold">Status of Tenders/Contracts</h2>
              </header>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-[#f7fafc] text-[#0d141c]/80">
                    <tr className="border-b border-[#e5e8eb]">
                      <th className="px-4 py-3 text-left w-16">S. No.</th>
                      <th className="px-4 py-3 text-left">Title</th>
                      <th className="px-4 py-3 text-left w-40">Upload Date</th>
                      <th className="px-4 py-3 text-left w-48">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r, idx) => (
                      <tr key={r.id} className="border-b border-[#e5e8eb]">
                        <td className="px-4 py-3">{idx + 1}</td>
                        <td className="px-4 py-3">
                          <a href="#" className="text-[#0766e5] hover:underline">
                            {r.title}
                          </a>
                        </td>
                        <td className="px-4 py-3">{r.date}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <button
                              aria-label="View"
                              className="rounded border border-[#e5e8eb] p-2 hover:bg-[#e6edff]"
                            >
                              <Eye className="h-4 w-4" />
                            </button>
                            <button
                              aria-label="Save"
                              className="rounded border border-[#e5e8eb] p-2 hover:bg-[#e6edff]"
                            >
                              <Bookmark className="h-4 w-4" />
                            </button>
                            <button className="ml-2 rounded border border-[#e5e8eb] px-3 py-1.5 text-xs font-medium hover:bg-[#e6edff]">
                              <Download className="mr-1 inline h-4 w-4 align-[-2px]" />
                              Download
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              <div className="flex items-center justify-center gap-1 p-4">
                {Array.from({ length: 10 }).map((_, i) => (
                  <button
                    key={i}
                    className={`h-8 w-8 rounded border border-[#e5e8eb] text-xs ${
                      i === 0 ? "bg-[#3c4ba7] text-[#ffffff]" : "hover:bg-[#e6edff]"
                    }`}
                    aria-current={i === 0 ? "page" : undefined}
                  >
                    {i + 1}
                  </button>
                ))}
              </div>
            </div>

            {/* Footer area */}
            <div className="mt-10 grid grid-cols-1 gap-10 md:grid-cols-2">
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">Important Links</h3>
                <ul className="list-none space-y-4">
                  <li>
                    <a className="text-[#0766e5] hover:underline underline-offset-2" href="#">
                      Media/Press Releases
                    </a>
                  </li>
                  <li>
                    <a className="text-[#0766e5] hover:underline underline-offset-2" href="#">
                      Training Institutes
                    </a>
                  </li>
                </ul>
                <div className="pt-2">
                  <h3 className="text-lg font-semibold">Contact Us</h3>
                  <div className="mt-4 text-sm leading-6">
                    <p>Indian Airport Authority Headquarters</p>
                    <p>Rajiv Gandhi Bhawan, Safdarjung Airport,</p>
                    <p>New Delhi: 110003</p>
                    <p>Phone: +91-11-12345678</p>
                    <p>Fax: +91-11-98765432</p>
                    <p>Email: contact@indianairportauthority.gov.in</p>
                  </div>
                </div>
              </div>
              <div className="flex items-start justify-end gap-6">
                <button aria-label="Next" className="rounded-full border border-[#e5e8eb] p-3 hover:bg-[#e6edff]" />
                <button aria-label="Next" className="rounded-full border border-[#e5e8eb] p-3 hover:bg-[#e6edff]" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
