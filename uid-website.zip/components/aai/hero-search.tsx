"use client"

import type React from "react"

import { useState } from "react"

export default function HeroSearch() {
  const pills = [
    "Careers",
    "Media",
    "Medical",
    "Lost & Found",
    "CPP Portal",
    "MoCA",
    "Cagan",
    "Grievances",
    "SHG Application",
    "RCS UDAN",
  ]
  const [query, setQuery] = useState("")

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    // no-op demo
  }

  return (
    <section className="w-full bg-[#e6edff]">
      <div className="mx-auto max-w-5xl px-6 py-8 md:py-10">
        <div className="flex items-center gap-3">
          {/* simple airplane mark */}
          <svg aria-hidden="true" className="h-8 w-8 text-[#0766e5]" viewBox="0 0 24 24" fill="currentColor">
            <path d="M2 12l20-7-5 7 5 7-20-7 7-2-7-5z" />
          </svg>
          <h1 className="text-balance text-2xl md:text-3xl font-semibold text-[#0766e5]">
            Airports Authority of India
          </h1>
        </div>

        <form
          onSubmit={onSubmit}
          className="mt-6 flex w-full items-stretch overflow-hidden rounded-md border border-[#e5e8eb] bg-[#ffffff]"
          role="search"
          aria-label="Site search"
        >
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Find Airports, Tenders, RTIs and more"
            className="w-full px-4 py-3 text-sm outline-none placeholder:text-[#0d141c]/60"
          />
          <button type="submit" className="bg-[#0766e5] px-5 py-3 text-sm font-medium text-[#ffffff] hover:opacity-95">
            Search Anything
          </button>
        </form>

        <div className="mt-4 flex flex-wrap gap-3">
          {pills.map((p) => (
            <a
              key={p}
              href="#"
              className="rounded-full border border-[#e5e8eb] bg-[#ffffff] px-3 py-1 text-xs text-[#0d141c] hover:bg-[#e6edff]"
            >
              {p}
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}
